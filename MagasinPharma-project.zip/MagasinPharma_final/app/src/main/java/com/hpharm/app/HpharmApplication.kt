package com.hpharm.app

import android.app.Application
import com.hpharm.app.data.AppDatabase
import com.hpharm.app.data.ProductRepository

class HpharmApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { ProductRepository(database.productDao(), database.stockTransactionDao()) }
}
