package com.hpharm.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.North
import androidx.compose.material.icons.filled.South
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import com.hpharm.app.ui.theme.AmbrePharmacie
import com.hpharm.app.ui.theme.CorailAlerte
import com.hpharm.app.ui.theme.LedgerNumber
import com.hpharm.app.ui.theme.LedgerNumberSmall
import com.hpharm.app.ui.theme.Sarcelle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    productId: Int,
    viewModel: ProductViewModel,
    onBack: () -> Unit
) {
    val product by viewModel.getProduct(productId).collectAsState(initial = null)
    val transactions by viewModel.getTransactionsForProduct(productId).collectAsState(initial = emptyList())

    var showTransactionDialog by remember { mutableStateOf<TransactionType?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var transactionQty by remember { mutableStateOf("1") }

    val currentProduct = product

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        if (currentProduct == null) {
            Box(modifier = Modifier.padding(padding).fillMaxSize())
            return@Scaffold
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                // Hero image with gradient scrim, title sits on the image
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(4f / 3f)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    if (currentProduct.imagePath != null) {
                        AsyncImage(
                            model = currentProduct.imagePath,
                            contentDescription = currentProduct.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            Icons.Default.Inventory2,
                            contentDescription = null,
                            modifier = Modifier.align(Alignment.Center).size(40.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomStart)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f))
                                )
                            )
                            .padding(top = 56.dp)
                            .padding(horizontal = 18.dp, vertical = 16.dp)
                    ) {
                        Column {
                            Text(
                                currentProduct.name,
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(15.dp))
                                Text(
                                    "  ${currentProduct.location}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatChip(label = "En stock", value = "${currentProduct.quantity}", modifier = Modifier.weight(1f))
                    if (currentProduct.expirationDate.isNotBlank()) {
                        StatChip(label = "Expiration", value = currentProduct.expirationDate, modifier = Modifier.weight(1f))
                    }
                }
            }

            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                ) {
                    Button(
                        onClick = { showTransactionDialog = TransactionType.IN },
                        colors = ButtonDefaults.buttonColors(containerColor = Sarcelle),
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.North, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("  Entrée", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { showTransactionDialog = TransactionType.OUT },
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.South, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("  Sortie", fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                Text(
                    "REGISTRE DES MOUVEMENTS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 26.dp, start = 18.dp, bottom = 6.dp)
                )
            }

            if (transactions.isEmpty()) {
                item {
                    Text(
                        "Aucun mouvement enregistré.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                    )
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    LedgerRow(tx)
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                }
            }

            item { Box(modifier = Modifier.height(24.dp)) }
        }

        if (showTransactionDialog != null) {
            val type = showTransactionDialog!!
            AlertDialog(
                onDismissRequest = { showTransactionDialog = null },
                title = { Text(if (type == TransactionType.IN) "Entrée de stock" else "Sortie de stock") },
                text = {
                    OutlinedTextField(
                        value = transactionQty,
                        onValueChange = { if (it.all { c -> c.isDigit() }) transactionQty = it },
                        label = { Text("Quantité") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val qty = transactionQty.toIntOrNull() ?: 0
                        if (qty > 0) {
                            viewModel.recordTransaction(currentProduct, type, qty)
                        }
                        transactionQty = "1"
                        showTransactionDialog = null
                    }) { Text("Confirmer", color = Sarcelle, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showTransactionDialog = null }) { Text("Annuler") }
                }
            )
        }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text("Supprimer") },
                text = { Text("Voulez-vous vraiment supprimer ce produit ?") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteProduct(currentProduct)
                        showDeleteDialog = false
                        onBack()
                    }) { Text("Supprimer", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) { Text("Annuler") }
                }
            )
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.medium)
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = LedgerNumber, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Signature element: a hairline-divided ledger, like a real stock register. */
@Composable
private fun LedgerRow(tx: StockTransaction) {
    val sdf = remember { SimpleDateFormat("dd MMM yyyy \u2014 HH:mm", Locale.FRANCE) }
    val isIn = tx.type == TransactionType.IN
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (isIn) Icons.Default.North else Icons.Default.South,
                contentDescription = null,
                tint = if (isIn) Sarcelle else CorailAlerte,
                modifier = Modifier.size(16.dp)
            )
            Column(modifier = Modifier.padding(start = 10.dp)) {
                Text(if (isIn) "Entrée" else "Sortie", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                Text(sdf.format(Date(tx.date)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            (if (isIn) "+" else "\u2212") + tx.quantity,
            style = LedgerNumber,
            color = if (isIn) Sarcelle else CorailAlerte
        )
    }
}
