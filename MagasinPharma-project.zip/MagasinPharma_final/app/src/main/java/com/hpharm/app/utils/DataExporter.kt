package com.hpharm.app.utils

import android.content.Context
import android.net.Uri
import com.hpharm.app.data.ExportSnapshot
import com.hpharm.app.data.Product
import com.hpharm.app.data.ProductImage
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** A transaction as read back from an imported file, not yet inserted into the database. */
data class ImportedTransaction(val type: TransactionType, val quantity: Int, val date: Long)

/** A product as read back from an imported file, not yet inserted into the database. */
data class ImportedProduct(
    val name: String,
    val keywords: String,
    val location: String,
    val quantity: Int,
    val expirationDate: String,
    val imageFiles: List<File>,
    val transactions: List<ImportedTransaction>
)

/**
 * Packs the whole database (products, all their photos, and their stock-movement history) into
 * a single .zip file that can be shared to another phone and re-imported there.
 */
object DataExporter {

    private const val EXPORT_VERSION = 1

    suspend fun exportToZip(context: Context, snapshot: ExportSnapshot): File = withContext(Dispatchers.IO) {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val zipFile = File(exportsDir, "MagasinPharma_export_${System.currentTimeMillis()}.zip")

        val productsJson = JSONArray()
        val imagesToZip = mutableListOf<Pair<String, File>>()
        var imageCounter = 0

        for (product in snapshot.products) {
            val rawImages = snapshot.imagesByProduct[product.id].orEmpty()
            // Legacy fallback: a product with a cover photo but no gallery rows yet.
            val effectiveImages = if (rawImages.isEmpty() && !product.imagePath.isNullOrBlank()) {
                listOf(ProductImage(id = -1, productId = product.id, imagePath = product.imagePath, position = 0))
            } else {
                rawImages
            }
            // Cover photo goes first so import's "first photo = cover" convention just works.
            val orderedImages = effectiveImages.sortedBy { img ->
                if (img.imagePath == product.imagePath) -1 else img.position
            }

            val imageNamesJson = JSONArray()
            for (img in orderedImages) {
                val sourceFile = File(img.imagePath)
                if (sourceFile.exists()) {
                    val nameInZip = "img_${imageCounter++}.jpg"
                    imageNamesJson.put(nameInZip)
                    imagesToZip.add(nameInZip to sourceFile)
                }
            }

            val transactionsJson = JSONArray()
            for (tx in snapshot.transactionsByProduct[product.id].orEmpty()) {
                val txJson = JSONObject()
                txJson.put("type", tx.type.name)
                txJson.put("quantity", tx.quantity)
                txJson.put("date", tx.date)
                transactionsJson.put(txJson)
            }

            val productJson = JSONObject()
            productJson.put("name", product.name)
            productJson.put("keywords", product.keywords)
            productJson.put("location", product.location)
            productJson.put("quantity", product.quantity)
            productJson.put("expirationDate", product.expirationDate)
            productJson.put("images", imageNamesJson)
            productJson.put("transactions", transactionsJson)
            productsJson.put(productJson)
        }

        val root = JSONObject()
        root.put("exportVersion", EXPORT_VERSION)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("products", productsJson)

        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
            zos.putNextEntry(ZipEntry("data.json"))
            zos.write(root.toString().toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            for ((nameInZip, sourceFile) in imagesToZip) {
                zos.putNextEntry(ZipEntry("images/$nameInZip"))
                sourceFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }

        zipFile
    }

    suspend fun importFromZip(context: Context, uri: Uri): List<ImportedProduct> = withContext(Dispatchers.IO) {
        val tempDir = File(context.cacheDir, "import_${System.currentTimeMillis()}").apply { mkdirs() }
        var jsonText: String? = null
        val extractedImages = mutableMapOf<String, File>()

        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(BufferedInputStream(input)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    when {
                        name == "data.json" -> {
                            jsonText = zis.readBytes().toString(Charsets.UTF_8)
                        }
                        name.startsWith("images/") -> {
                            val fileName = name.removePrefix("images/")
                            val outFile = File(tempDir, fileName)
                            FileOutputStream(outFile).use { out -> zis.copyTo(out) }
                            extractedImages[fileName] = outFile
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        val text = jsonText ?: return@withContext emptyList()
        val root = JSONObject(text)
        val productsJson = root.optJSONArray("products") ?: JSONArray()

        val result = mutableListOf<ImportedProduct>()
        for (i in 0 until productsJson.length()) {
            val p = productsJson.getJSONObject(i)

            val imageNames = p.optJSONArray("images") ?: JSONArray()
            val imageFiles = (0 until imageNames.length()).mapNotNull { idx ->
                extractedImages[imageNames.getString(idx)]
            }

            val txArray = p.optJSONArray("transactions") ?: JSONArray()
            val transactions = (0 until txArray.length()).map { idx ->
                val t = txArray.getJSONObject(idx)
                ImportedTransaction(
                    type = TransactionType.valueOf(t.getString("type")),
                    quantity = t.getInt("quantity"),
                    date = t.getLong("date")
                )
            }

            result.add(
                ImportedProduct(
                    name = p.optString("name", ""),
                    keywords = p.optString("keywords", ""),
                    location = p.optString("location", "Magasin 1"),
                    quantity = p.optInt("quantity", 0),
                    expirationDate = p.optString("expirationDate", ""),
                    imageFiles = imageFiles,
                    transactions = transactions
                )
            )
        }
        result
    }
}
