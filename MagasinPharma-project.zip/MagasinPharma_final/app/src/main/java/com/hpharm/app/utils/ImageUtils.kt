package com.hpharm.app.utils

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

/**
 * Copies an image selected from the gallery (or captured by the camera) into the app's
 * private "product_images" directory so it survives even if the original URI becomes
 * invalid, and returns the absolute path to the stored copy.
 */
object ImageUtils {

    fun persistImage(context: Context, sourceUri: Uri): String? {
        return try {
            val imagesDir = File(context.filesDir, "product_images").apply { mkdirs() }
            val destFile = File(imagesDir, "${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            destFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun createCaptureFile(context: Context): File {
        val capturedDir = File(context.cacheDir, "captured").apply { mkdirs() }
        return File(capturedDir, "${UUID.randomUUID()}.jpg")
    }

    /** Moves a freshly-captured photo from the temp cache location into permanent storage. */
    fun persistCapturedFile(context: Context, capturedFile: File): String? {
        return try {
            val imagesDir = File(context.filesDir, "product_images").apply { mkdirs() }
            val destFile = File(imagesDir, "${UUID.randomUUID()}.jpg")
            capturedFile.copyTo(destFile, overwrite = true)
            capturedFile.delete()
            destFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun deleteImage(path: String?) {
        if (path.isNullOrBlank()) return
        try {
            File(path).takeIf { it.exists() }?.delete()
        } catch (_: Exception) {
        }
    }
}
