package com.hpharm.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.hpharm.app.ui.AddProductScreen
import com.hpharm.app.ui.DashboardScreen
import com.hpharm.app.ui.DetailScreen
import com.hpharm.app.ui.HomeScreen
import com.hpharm.app.ui.ProductViewModel
import com.hpharm.app.ui.navigation.Screen
import com.hpharm.app.ui.theme.HpharmTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HpharmTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HpharmApp()
                }
            }
        }
    }
}

@Composable
fun HpharmApp() {
    val navController = rememberNavController()
    val viewModel: ProductViewModel = viewModel(factory = ProductViewModel.Factory)

    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onProductClick = { productId ->
                    navController.navigate(Screen.Detail.createRoute(productId))
                },
                onAddClick = { navController.navigate(Screen.AddProduct.route) },
                onNavigateToDashboard = { navController.navigate(Screen.Dashboard.route) }
            )
        }
        composable(Screen.AddProduct.route) {
            AddProductScreen(
                viewModel = viewModel,
                onDone = { navController.popBackStack() }
            )
        }
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = Screen.Detail.route,
            arguments = listOf(navArgument("productId") { type = NavType.IntType })
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getInt("productId") ?: 0
            DetailScreen(
                productId = productId,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
