package com.hpharm.app.data

import kotlinx.coroutines.flow.Flow

class ProductRepository(
    private val productDao: ProductDao,
    private val transactionDao: StockTransactionDao,
    private val imageDao: ProductImageDao
) {
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val recentTransactions: Flow<List<StockTransaction>> = transactionDao.getRecentTransactions(50)
    val productCount: Flow<Int> = productDao.getProductCount()

    fun searchProducts(query: String): Flow<List<Product>> = productDao.searchProducts(query)

    fun getProductById(id: Int): Flow<Product?> = productDao.getProductById(id)

    fun getTransactionsForProduct(productId: Int): Flow<List<StockTransaction>> =
        transactionDao.getTransactionsForProduct(productId)

    fun getImagesForProduct(productId: Int): Flow<List<ProductImage>> =
        imageDao.getImagesForProduct(productId)

    suspend fun addProduct(product: Product): Long = productDao.insert(product)

    suspend fun updateProduct(product: Product) = productDao.update(product)

    suspend fun deleteProduct(product: Product) = productDao.delete(product)

    /** Adds one or more photos to a product. If the product has no cover photo yet, the first new photo becomes the cover. */
    suspend fun addImages(product: Product, imagePaths: List<String>) {
        if (imagePaths.isEmpty()) return
        val startPosition = imageDao.countForProduct(product.id)
        val images = imagePaths.mapIndexed { i, path ->
            ProductImage(productId = product.id, imagePath = path, position = startPosition + i)
        }
        imageDao.insertAll(images)
        if (product.imagePath.isNullOrBlank()) {
            productDao.update(product.copy(imagePath = imagePaths.first()))
        }
    }

    /** Deletes a gallery photo. If it was the cover photo, promotes the next remaining photo (or clears the cover). */
    suspend fun deleteImage(product: Product, image: ProductImage, remainingAfterDelete: List<ProductImage>) {
        imageDao.delete(image)
        if (product.imagePath == image.imagePath) {
            val newCover = remainingAfterDelete.firstOrNull { it.id != image.id }?.imagePath
            productDao.update(product.copy(imagePath = newCover))
        }
    }

    suspend fun recordTransaction(product: Product, type: TransactionType, quantity: Int) {
        val newQuantity = when (type) {
            TransactionType.IN -> product.quantity + quantity
            TransactionType.OUT -> (product.quantity - quantity).coerceAtLeast(0)
        }
        productDao.updateQuantity(product.id, newQuantity)
        transactionDao.insert(
            StockTransaction(
                productId = product.id,
                productName = product.name,
                type = type,
                quantity = quantity
            )
        )
    }
}
