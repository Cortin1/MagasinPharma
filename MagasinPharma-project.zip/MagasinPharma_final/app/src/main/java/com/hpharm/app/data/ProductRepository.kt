package com.hpharm.app.data

import kotlinx.coroutines.flow.Flow

class ProductRepository(
    private val productDao: ProductDao,
    private val transactionDao: StockTransactionDao
) {
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val recentTransactions: Flow<List<StockTransaction>> = transactionDao.getRecentTransactions(50)
    val productCount: Flow<Int> = productDao.getProductCount()

    fun searchProducts(query: String): Flow<List<Product>> = productDao.searchProducts(query)

    fun getProductById(id: Int): Flow<Product?> = productDao.getProductById(id)

    fun getTransactionsForProduct(productId: Int): Flow<List<StockTransaction>> =
        transactionDao.getTransactionsForProduct(productId)

    suspend fun addProduct(product: Product): Long = productDao.insert(product)

    suspend fun updateProduct(product: Product) = productDao.update(product)

    suspend fun deleteProduct(product: Product) = productDao.delete(product)

    suspend fun recordTransaction(product: Product, type: TransactionType, quantity: Int) {
        val newQuantity = when (type) {
            TransactionType.IN -> product.quantity + quantity
            TransactionType.OUT -> (product.quantity - quantity).coerceAtLeast(0)
        }
        productDao.updateQuantity(product.id, newQuantity)
        transactionDao.insert(
            StockTransaction(
                productId = product.id,
                productName = product.name,
                type = type,
                quantity = quantity
            )
        )
    }
}
