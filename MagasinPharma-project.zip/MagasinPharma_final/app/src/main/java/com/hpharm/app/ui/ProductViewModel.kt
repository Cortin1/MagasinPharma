package com.hpharm.app.ui

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.hpharm.app.HpharmApplication
import com.hpharm.app.data.Product
import com.hpharm.app.data.ProductImage
import com.hpharm.app.data.ProductRepository
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import com.hpharm.app.utils.ImageUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProductViewModel(private val repository: ProductRepository) : ViewModel() {

    var searchQuery by mutableStateOf("")
        private set

    private val searchQueryFlow = MutableStateFlow("")

    val products: StateFlow<List<Product>> = searchQueryFlow
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allProducts else repository.searchProducts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val productCount: StateFlow<Int> =
        repository.productCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val recentTransactions: StateFlow<List<StockTransaction>> =
        repository.recentTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSearchQueryChanged(query: String) {
        searchQuery = query
        searchQueryFlow.value = query
    }

    fun getProduct(id: Int) = repository.getProductById(id)

    fun getTransactionsForProduct(id: Int) = repository.getTransactionsForProduct(id)

    fun getImagesForProduct(id: Int) = repository.getImagesForProduct(id)

    /** Creates a new product and, if any photos were selected, saves them all as its gallery (first = cover). */
    fun addProduct(product: Product, imagePaths: List<String> = emptyList(), onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.addProduct(product)
            if (imagePaths.isNotEmpty()) {
                repository.addImages(product.copy(id = id.toInt()), imagePaths)
            }
            onDone(id)
        }
    }

    /** Adds one or more newly-picked photos to an existing product's gallery. */
    fun addImagesToProduct(product: Product, context: Context, uris: List<Uri>) {
        viewModelScope.launch {
            val paths = uris.mapNotNull { ImageUtils.persistImage(context, it) }
            if (paths.isNotEmpty()) {
                repository.addImages(product, paths)
            }
        }
    }

    /** Removes a single photo from a product's gallery, promoting a new cover photo if needed. */
    fun deleteImage(product: Product, image: ProductImage, currentImages: List<ProductImage>) {
        viewModelScope.launch {
            repository.deleteImage(product, image, currentImages.filter { it.id != image.id })
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch { repository.updateProduct(product) }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch { repository.deleteProduct(product) }
    }

    fun recordTransaction(product: Product, type: TransactionType, quantity: Int) {
        viewModelScope.launch { repository.recordTransaction(product, type, quantity) }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
                val app = extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as HpharmApplication
                @Suppress("UNCHECKED_CAST")
                return ProductViewModel(app.repository) as T
            }
        }
    }
}
