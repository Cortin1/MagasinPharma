package com.hpharm.app.ui.theme

import androidx.compose.ui.graphics.Color

val PharmaGreen = Color(0xFF1B5E4F)
val PharmaGreenLight = Color(0xFF2E8B72)
val PharmaAccent = Color(0xFFE8B324)
val SurfaceLight = Color(0xFFF7F7F5)
val DangerRed = Color(0xFFC0392B)
