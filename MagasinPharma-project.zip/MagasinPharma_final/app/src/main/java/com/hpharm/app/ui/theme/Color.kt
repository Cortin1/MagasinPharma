package com.hpharm.app.ui.theme

import androidx.compose.ui.graphics.Color

// Named palette — clinical pharmacy identity, warm rather than sterile.

/** Primary: deep pharmacy teal, evokes surgical trust without feeling cold. */
val Sarcelle = Color(0xFF0F5D52)
val SarcelleDeep = Color(0xFF0A413A)
val SarcelleSoft = Color(0xFF1B7A6C)

/** Background: clinical ivory rather than sterile white or gray. */
val IvoireClinique = Color(0xFFFAF7F0)
val IvoireCard = Color(0xFFFFFFFF)
val IvoireTint = Color(0xFFF1ECDF)

/** Accent: warm apothecary amber — signage warmth, used sparingly. */
val AmbrePharmacie = Color(0xFFDB9A34)
val AmbreSoft = Color(0xFFF3DFB6)

/** Alert: soft coral for stock-outs and expiring items. */
val CorailAlerte = Color(0xFFE2574C)
val CorailSoft = Color(0xFFF7DAD7)

/** Ink: warm near-black for text, not pure black. */
val EncreNuit = Color(0xFF16211D)
val EncreMuted = Color(0xFF5B6B64)

/** Secondary: muted sage for borders and quiet accents. */
val Sauge = Color(0xFF6E9C8D)
