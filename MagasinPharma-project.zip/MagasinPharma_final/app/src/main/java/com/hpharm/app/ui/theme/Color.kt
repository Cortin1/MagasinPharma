package com.hpharm.app.ui.theme

import androidx.compose.ui.graphics.Color

// Three-color system (60/30/10): Violette (dominant), Ambre (secondary), Corail (accent).
// Dark surfaces are the app's signature default — not a system fallback.

/** Violette Électrique — dominant brand color (~60%). Replaces the expected medical green. */
val VioletVif = Color(0xFF7C5CFC)
val VioletProfond = Color(0xFF5B3FD6)
val VioletPale = Color(0xFFEDE7FF)

/** Ambre Doré — secondary (~30%). Warm apothecary gold, ties to cover-photo and emphasis. */
val AmbreDore = Color(0xFFF0A93B)
val AmbreProfond = Color(0xFFC6821F)
val AmbrePale = Color(0xFFFCE8C6)

/** Corail Vif — accent (~10%). Alerts, stock-outs, deletions. */
val CorailVif = Color(0xFFFF5A5F)
val CorailProfond = Color(0xFFD93B40)
val CorailPale = Color(0xFFFFDCDC)

/** Encre — dark surface system, four levels as recommended for real dark-mode depth. */
val EncreProfond = Color(0xFF0B0D12)      // true background
val EncreSurface = Color(0xFF171A21)      // elevated 1 (top bars, sheets)
val EncreSurfaceHaute = Color(0xFF1F232D) // elevated 2 (cards)
val EncreLigne = Color(0xFF2A2F3B)        // dividers, outlines

val BlancCasse = Color(0xFFF5F3F8)   // off-white text on dark
val GrisViolet = Color(0xFF9B96AA)   // muted secondary text, violet-tinted

// Light-theme surface equivalents (same brand hues, for system light mode).
val IvoireFond = Color(0xFFFAF9FC)
val IvoireCarte = Color(0xFFFFFFFF)
val EncreTexte = Color(0xFF17151F)
val GrisTexte = Color(0xFF6B6678)
