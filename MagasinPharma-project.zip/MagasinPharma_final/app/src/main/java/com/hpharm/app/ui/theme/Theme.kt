package com.hpharm.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Sarcelle,
    onPrimary = IvoireClinique,
    primaryContainer = SarcelleSoft,
    onPrimaryContainer = IvoireClinique,
    secondary = Sauge,
    onSecondary = EncreNuit,
    tertiary = AmbrePharmacie,
    onTertiary = EncreNuit,
    tertiaryContainer = AmbreSoft,
    background = IvoireClinique,
    onBackground = EncreNuit,
    surface = IvoireCard,
    onSurface = EncreNuit,
    surfaceVariant = IvoireTint,
    onSurfaceVariant = EncreMuted,
    error = CorailAlerte,
    onError = IvoireClinique,
    errorContainer = CorailSoft,
    onErrorContainer = CorailAlerte,
    outline = Sauge
)

private val DarkColors = darkColorScheme(
    primary = SarcelleSoft,
    onPrimary = EncreNuit,
    primaryContainer = SarcelleDeep,
    onPrimaryContainer = IvoireClinique,
    secondary = Sauge,
    tertiary = AmbrePharmacie,
    background = SarcelleDeep,
    surface = SarcelleDeep,
    error = CorailAlerte
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun HpharmTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
