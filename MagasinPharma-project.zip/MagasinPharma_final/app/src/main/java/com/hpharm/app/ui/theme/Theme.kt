package com.hpharm.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = PharmaGreen,
    secondary = PharmaGreenLight,
    tertiary = PharmaAccent,
    background = SurfaceLight,
    error = DangerRed
)

private val DarkColors = darkColorScheme(
    primary = PharmaGreenLight,
    secondary = PharmaGreen,
    tertiary = PharmaAccent,
    error = DangerRed
)

@Composable
fun HpharmTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
