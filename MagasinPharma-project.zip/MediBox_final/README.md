# Hpharm

Offline hospital pharmacy stock catalog. Add products with photos, search
them instantly, track quantity, and log stock in/out movements — no internet
required, everything stored locally on-device (Room/SQLite).

## Features

- **Home** — searchable grid of all products (name + keywords), live count, quick add button.
- **Add product** — name, keywords, storage location, quantity, expiration date (MM/AA), photo from gallery.
- **Detail** — view a product, record stock **in/out** transactions, delete the product.
- **Dashboard** — total products, total units, out-of-stock count, items expiring within 60 days, recent transaction log.

## Build

A GitHub Actions workflow (`.github/workflows/build.yml`) automatically builds
a debug APK on every push to `main`/`master`. After a push, check the
**Actions** tab of this repo, open the latest run, and download the
`app-debug-apk` artifact.

### Build locally

```
./gradlew assembleDebug
```

or, if you don't have the wrapper set up, install Gradle 8.7+ and Android SDK,
then run:

```
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`
