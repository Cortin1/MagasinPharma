package com.hpharm.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.RemoveShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import com.hpharm.app.ui.theme.AmbreDore
import com.hpharm.app.ui.theme.CorailVif
import com.hpharm.app.ui.theme.EncreLigne
import com.hpharm.app.ui.theme.LedgerNumber
import com.hpharm.app.ui.theme.VioletVif
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: ProductViewModel,
    onBack: () -> Unit
) {
    val products by viewModel.products.collectAsState()
    val transactions by viewModel.recentTransactions.collectAsState()

    val totalUnits = products.sumOf { it.quantity }
    val outOfStock = products.count { it.quantity == 0 }
    val expiringSoon = products.count { isExpiringSoon(it.expirationDate, Date()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tableau de bord", style = MaterialTheme.typography.titleLarge) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            HpharmBottomBar(selectedIsDashboard = true, onSelectHome = onBack, onSelectDashboard = {})
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                DataManagementSection(viewModel)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(Icons.Default.Inventory2, "Produits", "${products.size}", VioletVif, Modifier.weight(1f))
                    StatTile(Icons.Default.Inventory, "Unités totales", "$totalUnits", AmbreDore, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(Icons.Default.RemoveShoppingCart, "Rupture", "$outOfStock", CorailVif, Modifier.weight(1f))
                    StatTile(Icons.Default.EventBusy, "Expire < 60j", "$expiringSoon", CorailVif, Modifier.weight(1f))
                }
            }
            item {
                Text(
                    "MOUVEMENTS RÉCENTS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 14.dp, bottom = 2.dp)
                )
            }
            if (transactions.isEmpty()) {
                item {
                    Text(
                        "Aucun mouvement enregistré.",
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    Column {
                        DashboardLedgerRow(tx)
                        Divider(color = MaterialTheme.colorScheme.outline, thickness = 1.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DataManagementSection(viewModel: ProductViewModel) {
    val context = LocalContext.current

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            viewModel.importData(
                context = context,
                uri = uri,
                onImported = { count ->
                    Toast.makeText(context, "$count produit(s) importé(s)", Toast.LENGTH_LONG).show()
                },
                onError = {
                    Toast.makeText(context, "Échec de l'importation. Vérifiez le fichier.", Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    Column {
        Text(
            "DONNÉES",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    viewModel.exportData(
                        context = context,
                        onExported = { zipFile ->
                            val shareUri = FileProvider.getUriForFile(
                                context, "${context.packageName}.fileprovider", zipFile
                            )
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/zip"
                                putExtra(Intent.EXTRA_STREAM, shareUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Partager les données"))
                        },
                        onError = {
                            Toast.makeText(context, "Échec de l'exportation.", Toast.LENGTH_LONG).show()
                        }
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = VioletVif),
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("  Exporter", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { importLauncher.launch("application/zip") },
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("  Importer", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StatTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, EncreLigne)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(accent.copy(alpha = 0.16f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Text(value, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 10.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DashboardLedgerRow(tx: StockTransaction) {
    val sdf = remember { SimpleDateFormat("dd MMM \u2014 HH:mm", Locale.FRANCE) }
    val isIn = tx.type == TransactionType.IN
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(tx.productName, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text(sdf.format(Date(tx.date)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(
            (if (isIn) "+" else "\u2212") + tx.quantity,
            style = LedgerNumber,
            color = if (isIn) VioletVif else CorailVif
        )
    }
}

/**
 * A product is considered "expiring soon" if its MM/AA expiration date falls
 * within the next 60 days from [currentDate].
 */
fun isExpiringSoon(expirationDateStr: String, currentDate: Date): Boolean {
    if (expirationDateStr.isBlank()) return false
    return try {
        val parts = expirationDateStr.split("/")
        if (parts.size != 2) return false
        val month = parts[0].toInt()
        val year = 2000 + parts[1].toInt()

        val expiryCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val nowCal = Calendar.getInstance().apply { time = currentDate }
        val diffDays = (expiryCal.timeInMillis - nowCal.timeInMillis) / (1000 * 60 * 60 * 24)
        diffDays in 0..60
    } catch (e: Exception) {
        false
    }
}
