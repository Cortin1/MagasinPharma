package com.hpharm.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.hpharm.app.utils.BarcodeUtils
import com.hpharm.app.utils.ImageUtils
import java.io.File

/**
 * Returns a function that, when called, opens the phone's camera app to take a photo.
 * Once the photo is taken and confirmed, [onCaptured] is invoked with the final saved
 * file path. Uses the system camera via FileProvider — no CAMERA permission needed,
 * since the app never touches the camera hardware directly.
 */
@Composable
fun rememberCameraCaptureLauncher(onCaptured: (String) -> Unit): () -> Unit {
    val context = LocalContext.current
    var pendingFile by remember { mutableStateOf<File?>(null) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val file = pendingFile
        pendingFile = null
        if (success && file != null) {
            ImageUtils.persistCapturedFile(context, file)?.let(onCaptured)
        }
    }

    return {
        try {
            val file = ImageUtils.createCaptureFile(context)
            pendingFile = file
            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            launcher.launch(uri)
        } catch (e: Exception) {
            pendingFile = null
        }
    }
}

/**
 * Returns a function that, when called, opens the camera to photograph a barcode, then
 * decodes it fully on-device (no network). Calls [onScanned] with the decoded text on
 * success, or [onNotFound] if no barcode could be read from the photo. The scan photo
 * itself is discarded afterward — it's only ever used to read the code.
 */
@Composable
fun rememberBarcodeScanLauncher(onScanned: (String) -> Unit, onNotFound: () -> Unit = {}): () -> Unit {
    val context = LocalContext.current
    var pendingScanFile by remember { mutableStateOf<File?>(null) }

    val scanLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val file = pendingScanFile
        pendingScanFile = null
        if (success && file != null) {
            BarcodeUtils.scanBarcodeFromFile(file) { value ->
                file.delete()
                if (value != null) onScanned(value) else onNotFound()
            }
        }
    }

    return {
        try {
            val file = ImageUtils.createCaptureFile(context)
            pendingScanFile = file
            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            scanLauncher.launch(uri)
        } catch (e: Exception) {
            pendingScanFile = null
        }
    }
}
