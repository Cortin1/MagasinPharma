package com.hpharm.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.North
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.South
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hpharm.app.data.ProductImage
import com.hpharm.app.data.StockTransaction
import com.hpharm.app.data.TransactionType
import com.hpharm.app.ui.theme.CorailVif
import com.hpharm.app.ui.theme.LedgerNumber
import com.hpharm.app.ui.theme.VioletVif
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    productId: Int,
    viewModel: ProductViewModel,
    onBack: () -> Unit,
    onEditClick: (Int) -> Unit
) {
    val context = LocalContext.current
    val product by viewModel.getProduct(productId).collectAsState(initial = null)
    val images by viewModel.getImagesForProduct(productId).collectAsState(initial = emptyList())
    val transactions by viewModel.getTransactionsForProduct(productId).collectAsState(initial = emptyList())

    var showTransactionDialog by remember { mutableStateOf<TransactionType?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showPhotoSourceDialog by remember { mutableStateOf(false) }
    var transactionQty by remember { mutableStateOf("1") }

    val currentProduct = product

    val pickMoreImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty() && currentProduct != null) {
            viewModel.addImagesToProduct(currentProduct, context, uris)
        }
    }

    val launchCamera = rememberCameraCaptureLauncher { path ->
        currentProduct?.let { viewModel.addCapturedImageToProduct(it, path) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { onEditClick(productId) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Modifier")
                    }
                    IconButton(onClick = { showPhotoSourceDialog = true }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Ajouter des photos")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { padding ->
        if (currentProduct == null) {
            Box(modifier = Modifier.padding(padding).fillMaxSize())
            return@Scaffold
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                ProductGallery(
                    productName = currentProduct.name,
                    location = currentProduct.location,
                    images = images,
                    fallbackImagePath = currentProduct.imagePath,
                    onRemovePhoto = { image -> viewModel.deleteImage(currentProduct, image, images) }
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatChip(label = "En stock", value = "${currentProduct.quantity}", modifier = Modifier.weight(1f))
                    if (currentProduct.expirationDate.isNotBlank()) {
                        StatChip(label = "Expiration", value = currentProduct.expirationDate, modifier = Modifier.weight(1f))
                    }
                }
            }

            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)
                ) {
                    Button(
                        onClick = { showTransactionDialog = TransactionType.IN },
                        colors = ButtonDefaults.buttonColors(containerColor = VioletVif),
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.North, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("  Entrée", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { showTransactionDialog = TransactionType.OUT },
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.South, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("  Sortie", fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                Text(
                    "REGISTRE DES MOUVEMENTS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 26.dp, start = 18.dp, bottom = 6.dp)
                )
            }

            if (transactions.isEmpty()) {
                item {
                    Text(
                        "Aucun mouvement enregistré.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                    )
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    LedgerRow(tx)
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                }
            }

            item { Box(modifier = Modifier.height(24.dp)) }
        }

        if (showTransactionDialog != null) {
            val type = showTransactionDialog!!
            AlertDialog(
                onDismissRequest = { showTransactionDialog = null },
                title = { Text(if (type == TransactionType.IN) "Entrée de stock" else "Sortie de stock") },
                text = {
                    OutlinedTextField(
                        value = transactionQty,
                        onValueChange = { if (it.all { c -> c.isDigit() }) transactionQty = it },
                        label = { Text("Quantité") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val qty = transactionQty.toIntOrNull() ?: 0
                        if (qty > 0) {
                            viewModel.recordTransaction(currentProduct, type, qty)
                        }
                        transactionQty = "1"
                        showTransactionDialog = null
                    }) { Text("Confirmer", color = VioletVif, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showTransactionDialog = null }) { Text("Annuler") }
                }
            )
        }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text("Supprimer") },
                text = { Text("Voulez-vous vraiment supprimer ce produit ?") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteProduct(currentProduct)
                        showDeleteDialog = false
                        onBack()
                    }) { Text("Supprimer", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) { Text("Annuler") }
                }
            )
        }

        if (showPhotoSourceDialog) {
            AlertDialog(
                onDismissRequest = { showPhotoSourceDialog = false },
                title = { Text("Ajouter une photo") },
                text = {
                    Column {
                        TextButton(
                            onClick = { showPhotoSourceDialog = false; launchCamera() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = VioletVif)
                                Text("  Prendre une photo")
                            }
                        }
                        TextButton(
                            onClick = { showPhotoSourceDialog = false; pickMoreImagesLauncher.launch("image/*") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = VioletVif)
                                Text("  Choisir depuis la galerie")
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPhotoSourceDialog = false }) { Text("Annuler") }
                }
            )
        }
    }
}

/**
 * Swipeable photo gallery. Falls back to the product's legacy single cover photo if the
 * gallery table has no rows yet (e.g. data created before multi-photo support existed).
 */
@Composable
private fun ProductGallery(
    productName: String,
    location: String,
    images: List<ProductImage>,
    fallbackImagePath: String?,
    onRemovePhoto: (ProductImage) -> Unit
) {
    val listState = rememberLazyListState()
    val displayImages = if (images.isNotEmpty()) {
        images
    } else if (fallbackImagePath != null) {
        listOf(ProductImage(id = -1, productId = -1, imagePath = fallbackImagePath, position = 0))
    } else {
        emptyList()
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        if (displayImages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(40.dp))
            }
        } else {
            LazyRow(state = listState) {
                items(displayImages, key = { it.id }) { image ->
                    Box(
                        modifier = Modifier
                            .fillParentMaxWidth()
                            .aspectRatio(4f / 3f)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        AsyncImage(
                            model = image.imagePath,
                            contentDescription = productName,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        if (image.id != -1) {
                            IconButton(
                                onClick = { onRemovePhoto(image) },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 108.dp, end = 8.dp)
                                    .size(32.dp)
                                    .background(Color.Black.copy(alpha = 0.35f), MaterialTheme.shapes.extraSmall)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Retirer la photo", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
            if (displayImages.size > 1) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 64.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    displayImages.forEachIndexed { i, _ ->
                        val active = i == listState.firstVisibleItemIndex
                        Box(
                            modifier = Modifier
                                .size(if (active) 7.dp else 5.dp)
                                .background(
                                    if (active) Color.White else Color.White.copy(alpha = 0.5f),
                                    MaterialTheme.shapes.extraSmall
                                )
                        )
                    }
                }
            }
        }

        // Title + location scrim, sits over the last-visible photo
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)))
                )
                .padding(top = 56.dp)
                .padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Column {
                Text(productName, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(15.dp))
                    Text("  $location", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
                }
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.medium)
            .padding(14.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = LedgerNumber, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Signature element: a hairline-divided ledger, like a real stock register. */
@Composable
private fun LedgerRow(tx: StockTransaction) {
    val sdf = remember { SimpleDateFormat("dd MMM yyyy \u2014 HH:mm", Locale.FRANCE) }
    val isIn = tx.type == TransactionType.IN
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (isIn) Icons.Default.North else Icons.Default.South,
                contentDescription = null,
                tint = if (isIn) VioletVif else CorailVif,
                modifier = Modifier.size(16.dp)
            )
            Column(modifier = Modifier.padding(start = 10.dp)) {
                Text(if (isIn) "Entrée" else "Sortie", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                Text(sdf.format(Date(tx.date)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            (if (isIn) "+" else "\u2212") + tx.quantity,
            style = LedgerNumber,
            color = if (isIn) VioletVif else CorailVif
        )
    }
}
