package com.hpharm.app.data

enum class ProductCategory(val displayName: String) {
    AIGUILLES("Aiguilles"),
    CATHETERS("Cathéters"),
    SERINGUES("Seringues"),
    TUBES_PRELEVEMENT("Tubes de prélèvement"),
    PANSEMENTS("Pansements"),
    GANTS("Gants"),
    PERFUSION("Perfusion"),
    COMPRESSES("Compresses"),
    DESINFECTION("Désinfection"),
    AUTRE("Autre")
}
