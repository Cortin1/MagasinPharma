package com.hpharm.app.ui.theme

import androidx.compose.ui.graphics.Color

// MediBox brand system, sampled directly from the official logo:
// Sarcelle/Teal (primary interactive — the "Box" wordmark + checkmark),
// Bleu (secondary — capsule side panels), Navy (structural — the "Medi" wordmark + base).
// Symbol names below (VioletVif, AmbreDore, CorailVif...) are historical and no longer
// describe their own hue, but are kept as-is so every screen file stays unchanged and safe.

/** Primary interactive color (~ex-"Violette" slot). Sampled from the logo's teal/checkmark. */
val VioletVif = Color(0xFF1CA9A6)
val VioletProfond = Color(0xFF157F7D)
val VioletPale = Color(0xFFD7F3F1)

/** Secondary color (~ex-"Ambre" slot). Sampled from the logo's mid-blue capsule panels. */
val AmbreDore = Color(0xFF1479B5)
val AmbreProfond = Color(0xFF0F5D8C)
val AmbrePale = Color(0xFFDCEEF9)

/** Alert/critical color — kept separate from the logo's palette on purpose (stock-outs, deletions). */
val CorailVif = Color(0xFFFF5A5F)
val CorailProfond = Color(0xFFD93B40)
val CorailPale = Color(0xFFFFDCDC)

/** MediBox Navy — the logo's dominant structural color ("Medi" wordmark, drawer base). */
val MediNavy = Color(0xFF0A3D75)
val MediNavyProfond = Color(0xFF072A56)
val MediNavyPale = Color(0xFFE3ECF7)

/** Encre — dark surface system, navy-tinted to match the new brand, four levels for real depth. */
val EncreProfond = Color(0xFF070B12)      // true background
val EncreSurface = Color(0xFF11151F)      // elevated 1 (top bars, sheets)
val EncreSurfaceHaute = Color(0xFF181D29) // elevated 2 (cards)
val EncreLigne = Color(0xFF262C3A)        // dividers, outlines

val BlancCasse = Color(0xFFF5F7FA)   // off-white text on dark
val GrisViolet = Color(0xFF9AA3B5)   // muted secondary text, navy-tinted

// Light-theme surface equivalents (same brand hues, for system light mode).
val IvoireFond = Color(0xFFF7FAFC)
val IvoireCarte = Color(0xFFFFFFFF)
val EncreTexte = Color(0xFF0F1520)
val GrisTexte = Color(0xFF5C6577)
