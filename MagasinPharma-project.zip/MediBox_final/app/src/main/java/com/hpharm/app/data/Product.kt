package com.hpharm.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val keywords: String = "",
    val location: String = "Magasin 1",
    val quantity: Int = 0,
    val expirationDate: String = "",
    val imagePath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
