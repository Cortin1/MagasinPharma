package com.hpharm.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** A single photo belonging to a product's gallery. Position 0 is the cover photo. */
@Entity(
    tableName = "product_images",
    foreignKeys = [
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("productId")]
)
data class ProductImage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int,
    val imagePath: String,
    val position: Int = 0
)
