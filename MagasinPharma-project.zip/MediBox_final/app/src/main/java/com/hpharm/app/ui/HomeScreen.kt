package com.hpharm.app.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hpharm.app.data.Product
import com.hpharm.app.data.ProductCategory
import com.hpharm.app.ui.theme.AmbreDore
import com.hpharm.app.ui.theme.CorailVif
import com.hpharm.app.ui.theme.EncreLigne
import com.hpharm.app.ui.theme.EncreProfond
import com.hpharm.app.ui.theme.LedgerNumberSmall
import com.hpharm.app.ui.theme.MediNavyProfond
import com.hpharm.app.ui.theme.VioletVif
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: ProductViewModel,
    onProductClick: (Int) -> Unit,
    onAddClick: () -> Unit,
    onNavigateToDashboard: () -> Unit
) {
    val products by viewModel.products.collectAsState()
    val count by viewModel.productCount.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val pendingDeleteName = viewModel.pendingDeleteProductName
    val context = LocalContext.current
    val launchBarcodeScan = rememberBarcodeScanLauncher(
        onScanned = { value -> viewModel.onSearchQueryChanged(value) },
        onNotFound = { Toast.makeText(context, "Aucun code-barres détecté, réessayez.", Toast.LENGTH_SHORT).show() }
    )

    LaunchedEffect(pendingDeleteName) {
        if (pendingDeleteName != null) {
            val result = snackbarHostState.showSnackbar(
                message = "\u00ab $pendingDeleteName \u00bb supprimé",
                actionLabel = "Annuler",
                duration = SnackbarDuration.Long
            )
            if (result == SnackbarResult.ActionPerformed) {
                viewModel.undoDelete()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddClick,
                containerColor = AmbreDore,
                contentColor = EncreProfond,
                icon = { Icon(Icons.Default.Inventory2, contentDescription = null) },
                text = { Text("Nouveau", fontWeight = FontWeight.Bold) }
            )
        },
        bottomBar = {
            HpharmBottomBar(selectedIsDashboard = false, onSelectDashboard = onNavigateToDashboard, onSelectHome = {})
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            // Hero header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(MediNavyProfond, VioletVif)))
                    .padding(horizontal = 20.dp, vertical = 22.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.LocalPharmacy,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            "  MediBox",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Text(
                        "$count produits en stock",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    // Glass-style search field
                    TextField(
                        value = viewModel.searchQuery,
                        onValueChange = { viewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                            .border(1.dp, Color.White.copy(alpha = 0.22f), MaterialTheme.shapes.small),
                        placeholder = { Text("Rechercher un produit...", color = Color.White.copy(alpha = 0.65f)) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AmbreDore) },
                        trailingIcon = {
                            if (viewModel.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Effacer", tint = Color.White)
                                }
                            } else {
                                IconButton(onClick = { launchBarcodeScan() }) {
                                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Scanner un code-barres", tint = Color.White)
                                }
                            }
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.small,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White.copy(alpha = 0.12f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.12f),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = AmbreDore
                        )
                    )
                }
            }

            // Category filter chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    CategoryChip(
                        label = "Tous",
                        selected = viewModel.selectedCategory == null,
                        onClick = { viewModel.onCategorySelected(null) }
                    )
                }
                items(ProductCategory.entries.toList()) { category ->
                    CategoryChip(
                        label = category.displayName,
                        selected = viewModel.selectedCategory == category,
                        onClick = {
                            viewModel.onCategorySelected(if (viewModel.selectedCategory == category) null else category)
                        }
                    )
                }
            }

            if (products.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Inventory2,
                            contentDescription = null,
                            modifier = Modifier.padding(bottom = 8.dp).size(36.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            if (viewModel.searchQuery.isBlank()) "Aucun produit. Appuyez sur \u00ab Nouveau \u00bb pour commencer."
                            else "Aucun résultat pour \u00ab ${viewModel.searchQuery} \u00bb",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(14.dp, 14.dp, 14.dp, 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(products) { index, product ->
                        StaggeredEntry(index = index) {
                            ProductCard(product = product, onClick = { onProductClick(product.id) })
                        }
                    }
                }
            }
        }
    }
}

/** Bottom nav shared by the two top-level screens, kept in the thumb-reachable zone. */
@Composable
fun HpharmBottomBar(selectedIsDashboard: Boolean, onSelectHome: () -> Unit, onSelectDashboard: () -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(
            selected = !selectedIsDashboard,
            onClick = onSelectHome,
            icon = { Icon(Icons.Default.Inventory2, contentDescription = "Accueil") },
            label = { Text("Accueil") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VioletVif,
                selectedTextColor = VioletVif,
                indicatorColor = VioletVif.copy(alpha = 0.16f)
            )
        )
        NavigationBarItem(
            selected = selectedIsDashboard,
            onClick = onSelectDashboard,
            icon = { Icon(Icons.Default.Analytics, contentDescription = "Tableau de bord") },
            label = { Text("Tableau de bord") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VioletVif,
                selectedTextColor = VioletVif,
                indicatorColor = VioletVif.copy(alpha = 0.16f)
            )
        )
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        shape = MaterialTheme.shapes.extraSmall,
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = VioletVif,
            selectedLabelColor = Color.White
        )
    )
}

@Composable
private fun StaggeredEntry(index: Int, content: @Composable () -> Unit) {
    var visible by remember(index) { mutableStateOf(false) }
    LaunchedEffect(index) {
        delay((index.coerceAtMost(10) * 28).toLong())
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(220)) + slideInVertically(tween(220)) { it / 6 }
    ) {
        content()
    }
}

@Composable
fun ProductCard(product: Product, onClick: () -> Unit) {
    val stockColor = when {
        product.quantity == 0 -> CorailVif
        product.quantity < 5 -> AmbreDore
        else -> VioletVif
    }
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EncreLigne)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                if (product.imagePath != null) {
                    AsyncImage(
                        model = product.imagePath,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        Icons.Default.Inventory2,
                        contentDescription = null,
                        modifier = Modifier.align(Alignment.Center),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(stockColor, CircleShape)
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        "${product.quantity}",
                        style = LedgerNumberSmall,
                        color = Color.White
                    )
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    product.name,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    product.location,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
