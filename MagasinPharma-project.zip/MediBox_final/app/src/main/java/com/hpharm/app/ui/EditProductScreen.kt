package com.hpharm.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.hpharm.app.data.ProductCategory
import com.hpharm.app.ui.theme.AmbreDore
import com.hpharm.app.ui.theme.VioletVif

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProductScreen(
    productId: Int,
    viewModel: ProductViewModel,
    onDone: () -> Unit
) {
    val product by viewModel.getProduct(productId).collectAsState(initial = null)
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    val aliasFields = remember { mutableStateListOf("") }
    var location by remember { mutableStateOf("") }
    var expirationDate by remember { mutableStateOf(TextFieldValue("")) }
    var category by remember { mutableStateOf(ProductCategory.AUTRE) }
    var initialized by remember { mutableStateOf(false) }

    val launchBarcodeScan = rememberBarcodeScanLauncher(
        onScanned = { value ->
            val emptyIndex = aliasFields.indexOfFirst { it.isBlank() }
            if (emptyIndex >= 0) aliasFields[emptyIndex] = value else aliasFields.add(value)
        },
        onNotFound = { Toast.makeText(context, "Aucun code-barres détecté, réessayez.", Toast.LENGTH_SHORT).show() }
    )

    // Pre-fill the form once, the first time the product loads — without this guard,
    // every recomposition would stomp over whatever the user has already typed.
    LaunchedEffect(product) {
        val current = product
        if (current != null && !initialized) {
            name = current.name
            val existingAliases = current.keywords.split("|").map { it.trim() }.filter { it.isNotBlank() }
            aliasFields.clear()
            aliasFields.addAll(if (existingAliases.isEmpty()) listOf("") else existingAliases)
            location = current.location
            expirationDate = TextFieldValue(current.expirationDate, selection = TextRange(current.expirationDate.length))
            category = current.category
            initialized = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Modifier le produit", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        val currentProduct = product
        if (currentProduct == null) {
            Box(modifier = Modifier.padding(padding).fillMaxSize())
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            EditFormSection(title = "IDENTIFICATION") {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nom du produit") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.small,
                    colors = editFieldColors()
                )
                Text(
                    "Autres noms",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
                )
                AliasFieldsList(
                    aliasFields = aliasFields,
                    onValueChange = { index, value -> aliasFields[index] = value },
                    onRemove = { index -> aliasFields.removeAt(index) },
                    onAdd = { aliasFields.add("") }
                )
                OutlinedButton(
                    onClick = { launchBarcodeScan() },
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Scanner un code-barres", fontWeight = FontWeight.Medium)
                }
            }

            EditFormSection(title = "STOCK") {
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Emplacement") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.small,
                    colors = editFieldColors()
                )
                OutlinedTextField(
                    value = expirationDate,
                    onValueChange = { new ->
                        val formattedText = formatExpirationInput(new.text, expirationDate.text)
                        expirationDate = TextFieldValue(
                            text = formattedText,
                            selection = TextRange(formattedText.length)
                        )
                    },
                    label = { Text("Expiration") },
                    placeholder = { Text("MM/AA") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    shape = MaterialTheme.shapes.small,
                    colors = editFieldColors()
                )
            }

            EditFormSection(title = "CATÉGORIE") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ProductCategory.entries.toList()) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.displayName) },
                            shape = MaterialTheme.shapes.extraSmall,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VioletVif,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.updateProduct(
                            currentProduct.copy(
                                name = name.trim(),
                                keywords = aliasFields.filter { it.isNotBlank() }.joinToString(" | ") { it.trim() },
                                location = location.trim().ifBlank { "Magasin 1" },
                                expirationDate = expirationDate.text.trim(),
                                category = category
                            )
                        )
                        onDone()
                    }
                },
                enabled = name.isNotBlank(),
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.buttonColors(containerColor = VioletVif),
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            ) {
                Text("Enregistrer les modifications", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 4.dp))
            }
        }
    }
}

@Composable
private fun editFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = VioletVif,
    focusedLabelColor = VioletVif,
    cursorColor = AmbreDore
)

@Composable
private fun EditFormSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(
            title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
        )
        content()
    }
}
