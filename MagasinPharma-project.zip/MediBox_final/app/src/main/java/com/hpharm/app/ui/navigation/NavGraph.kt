package com.hpharm.app.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object AddProduct : Screen("add_product")
    data object Dashboard : Screen("dashboard")
    data object Detail : Screen("detail/{productId}") {
        fun createRoute(productId: Int) = "detail/$productId"
    }
    data object Edit : Screen("edit/{productId}") {
        fun createRoute(productId: Int) = "edit/$productId"
    }
}
