package com.hpharm.app.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.File
import java.io.OutputStream
import java.util.UUID

/**
 * Saves images into the app's private "product_images" directory, compressing them on the way
 * in (resized + re-encoded JPEG) so a single product photo takes hundreds of KB instead of the
 * 8-15MB a modern phone camera produces by default — this is what keeps on-device storage and
 * exported backup files small without any visible loss in quality at normal viewing sizes.
 */
object ImageUtils {

    private const val MAX_DIMENSION = 1600
    private const val JPEG_QUALITY = 82

    /** Files already smaller than this are assumed to already be compressed; re-encoding them
     *  again would only cost quality for no real size benefit, so they're copied as-is. */
    private const val ALREADY_SMALL_THRESHOLD_BYTES = 450_000L

    fun persistImage(context: Context, sourceUri: Uri): String? {
        return try {
            val imagesDir = File(context.filesDir, "product_images").apply { mkdirs() }
            val destFile = File(imagesDir, "${UUID.randomUUID()}.jpg")
            val bytes = context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
                ?: return null
            destFile.outputStream().use { out ->
                if (!compressBytesToStream(bytes, out, MAX_DIMENSION, JPEG_QUALITY)) return null
            }
            destFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun createCaptureFile(context: Context): File {
        val capturedDir = File(context.cacheDir, "captured").apply { mkdirs() }
        return File(capturedDir, "${UUID.randomUUID()}.jpg")
    }

    /**
     * Moves a photo from a temp cache location into permanent storage.
     * [compress] should stay true for fresh camera captures, and be set to false only when
     * re-saving a photo that was already compressed by an export (e.g. during import), to avoid
     * repeatedly re-encoding the same JPEG and losing quality generation after generation.
     */
    fun persistCapturedFile(context: Context, capturedFile: File, compress: Boolean = true): String? {
        return try {
            val imagesDir = File(context.filesDir, "product_images").apply { mkdirs() }
            val destFile = File(imagesDir, "${UUID.randomUUID()}.jpg")
            if (compress) {
                val bytes = capturedFile.readBytes()
                destFile.outputStream().use { out ->
                    if (!compressBytesToStream(bytes, out, MAX_DIMENSION, JPEG_QUALITY)) return null
                }
            } else {
                capturedFile.copyTo(destFile, overwrite = true)
            }
            capturedFile.delete()
            destFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun deleteImage(path: String?) {
        if (path.isNullOrBlank()) return
        try {
            File(path).takeIf { it.exists() }?.delete()
        } catch (_: Exception) {
        }
    }

    /**
     * Writes an existing on-disk image into [out], compressing it first if it looks like an
     * uncompressed original (large file), or copying it as-is if it's already small enough —
     * used when building an export so old, pre-compression photos still get squeezed down.
     */
    fun writeImageForExport(sourceFile: File, out: OutputStream): Boolean {
        return try {
            if (sourceFile.length() <= ALREADY_SMALL_THRESHOLD_BYTES) {
                sourceFile.inputStream().use { it.copyTo(out) }
                true
            } else {
                val bytes = sourceFile.readBytes()
                compressBytesToStream(bytes, out, MAX_DIMENSION, JPEG_QUALITY)
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Decodes, downsizes, corrects EXIF rotation, and re-encodes as JPEG into [out]. */
    private fun compressBytesToStream(bytes: ByteArray, out: OutputStream, maxDimension: Int, quality: Int): Boolean {
        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOptions)
            if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) return false

            var sampleSize = 1
            while (boundsOptions.outWidth / (sampleSize * 2) >= maxDimension &&
                boundsOptions.outHeight / (sampleSize * 2) >= maxDimension
            ) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            var bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions) ?: return false

            val largestSide = maxOf(bitmap.width, bitmap.height)
            if (largestSide > maxDimension) {
                val scale = maxDimension.toFloat() / largestSide
                val newWidth = (bitmap.width * scale).toInt().coerceAtLeast(1)
                val newHeight = (bitmap.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
                if (scaled != bitmap) bitmap.recycle()
                bitmap = scaled
            }

            val rotationDegrees = try {
                val exif = ExifInterface(ByteArrayInputStream(bytes))
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } catch (e: Exception) {
                0f
            }
            if (rotationDegrees != 0f) {
                val matrix = Matrix().apply { postRotate(rotationDegrees) }
                val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                if (rotated != bitmap) bitmap.recycle()
                bitmap = rotated
            }

            val compressOk = bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bitmap.recycle()
            compressOk
        } catch (e: Exception) {
            false
        }
    }
}
