package com.hpharm.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { IN, OUT }

@Entity(tableName = "stock_transactions")
data class StockTransaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int,
    val productName: String,
    val type: TransactionType,
    val quantity: Int,
    val date: Long = System.currentTimeMillis()
)
