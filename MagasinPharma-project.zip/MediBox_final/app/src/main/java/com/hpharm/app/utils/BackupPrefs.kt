package com.hpharm.app.utils

import android.content.Context

/** Tracks when the user last exported their data, to power the backup reminder banner. */
object BackupPrefs {
    private const val PREFS_NAME = "medibox_prefs"
    private const val KEY_LAST_EXPORT = "last_export_timestamp"

    fun getLastExportTime(context: Context): Long =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getLong(KEY_LAST_EXPORT, 0L)

    fun setLastExportTimeNow(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_LAST_EXPORT, System.currentTimeMillis())
            .apply()
    }

    /** Returns Long.MAX_VALUE if never exported, so "overdue" checks always trigger correctly. */
    fun daysSinceLastExport(context: Context): Long {
        val last = getLastExportTime(context)
        if (last == 0L) return Long.MAX_VALUE
        val diffMs = System.currentTimeMillis() - last
        return diffMs / (1000L * 60 * 60 * 24)
    }
}
