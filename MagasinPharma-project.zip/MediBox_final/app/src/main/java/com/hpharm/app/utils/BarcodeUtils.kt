package com.hpharm.app.utils

import android.graphics.BitmapFactory
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.File

/** Decodes a barcode from a photo file, using the fully on-device (offline) ML Kit model —
 *  not the Play-Services-backed variant, so this never touches the network. */
object BarcodeUtils {

    fun scanBarcodeFromFile(file: File, onResult: (String?) -> Unit) {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
        if (bitmap == null) {
            onResult(null)
            return
        }
        val image = InputImage.fromBitmap(bitmap, 0)
        val scanner = BarcodeScanning.getClient()
        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                onResult(barcodes.firstOrNull()?.rawValue)
            }
            .addOnFailureListener {
                onResult(null)
            }
    }
}
