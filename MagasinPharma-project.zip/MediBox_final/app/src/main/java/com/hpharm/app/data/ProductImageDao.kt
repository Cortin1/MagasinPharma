package com.hpharm.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductImageDao {

    @Query("SELECT * FROM product_images WHERE productId = :productId ORDER BY position ASC")
    fun getImagesForProduct(productId: Int): Flow<List<ProductImage>>

    @Query("SELECT * FROM product_images ORDER BY productId ASC, position ASC")
    suspend fun getAllImagesOnce(): List<ProductImage>

    @Query("SELECT COUNT(*) FROM product_images WHERE productId = :productId")
    suspend fun countForProduct(productId: Int): Int

    @Insert
    suspend fun insert(image: ProductImage): Long

    @Insert
    suspend fun insertAll(images: List<ProductImage>)

    @Delete
    suspend fun delete(image: ProductImage)
}
