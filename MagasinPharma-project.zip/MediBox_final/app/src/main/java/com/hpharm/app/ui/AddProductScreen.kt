package com.hpharm.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.hpharm.app.data.Product
import com.hpharm.app.ui.theme.AmbreDore
import com.hpharm.app.ui.theme.VioletVif
import com.hpharm.app.utils.ImageUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductScreen(
    viewModel: ProductViewModel,
    onDone: () -> Unit
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var keywords by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Magasin 1") }
    var quantity by remember { mutableStateOf("0") }
    var expirationDate by remember { mutableStateOf(TextFieldValue("")) }
    val imagePaths = remember { mutableStateListOf<String>() }
    var showPhotoSourceDialog by remember { mutableStateOf(false) }

    val pickImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        uris.forEach { uri ->
            ImageUtils.persistImage(context, uri)?.let { imagePaths.add(it) }
        }
    }

    val launchCamera = rememberCameraCaptureLauncher { path -> imagePaths.add(path) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nouveau produit", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onDone) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            FormSection(title = "PHOTOS (${imagePaths.size})") {
                PhotoStrip(
                    imagePaths = imagePaths,
                    onAddClick = { showPhotoSourceDialog = true },
                    onRemove = { path -> imagePaths.remove(path) }
                )
            }

            FormSection(title = "IDENTIFICATION") {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nom du produit") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.small,
                    colors = fieldColors()
                )
                OutlinedTextField(
                    value = keywords,
                    onValueChange = { keywords = it },
                    label = { Text("Autres noms / mots-clés") },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    shape = MaterialTheme.shapes.small,
                    colors = fieldColors()
                )
            }

            FormSection(title = "STOCK") {
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Emplacement") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.small,
                    colors = fieldColors()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 10.dp)) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { if (it.all { c -> c.isDigit() }) quantity = it },
                        label = { Text("Quantité") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = MaterialTheme.shapes.small,
                        colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = expirationDate,
                        onValueChange = { new ->
                            val formattedText = formatExpirationInput(new.text, expirationDate.text)
                            expirationDate = TextFieldValue(
                                text = formattedText,
                                selection = TextRange(formattedText.length)
                            )
                        },
                        label = { Text("Expiration") },
                        placeholder = { Text("MM/AA") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = MaterialTheme.shapes.small,
                        colors = fieldColors()
                    )
                }
            }

            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addProduct(
                            product = Product(
                                name = name.trim(),
                                keywords = keywords.trim(),
                                location = location.trim().ifBlank { "Magasin 1" },
                                quantity = quantity.toIntOrNull() ?: 0,
                                expirationDate = expirationDate.text.trim(),
                                imagePath = imagePaths.firstOrNull()
                            ),
                            imagePaths = imagePaths.toList()
                        ) { onDone() }
                    }
                },
                enabled = name.isNotBlank(),
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.buttonColors(containerColor = VioletVif),
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            ) {
                Text("Enregistrer", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 4.dp))
            }
        }

        if (showPhotoSourceDialog) {
            AlertDialog(
                onDismissRequest = { showPhotoSourceDialog = false },
                title = { Text("Ajouter une photo") },
                text = {
                    Column {
                        TextButton(
                            onClick = { showPhotoSourceDialog = false; launchCamera() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = VioletVif)
                                Text("  Prendre une photo")
                            }
                        }
                        TextButton(
                            onClick = { showPhotoSourceDialog = false; pickImagesLauncher.launch("image/*") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = VioletVif)
                                Text("  Choisir depuis la galerie")
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPhotoSourceDialog = false }) { Text("Annuler") }
                }
            )
        }
    }
}

/**
 * Formats expiration-date input as MM/AA, auto-inserting the "/" right after the
 * two month digits are typed. Deletions are left untouched so backspacing feels natural.
 */
private fun formatExpirationInput(new: String, old: String): String {
    if (new.length < old.length) return new
    val digitsOnly = new.filter { it.isDigit() }.take(4)
    return when {
        digitsOnly.length < 2 -> digitsOnly
        digitsOnly.length == 2 -> "$digitsOnly/"
        else -> digitsOnly.substring(0, 2) + "/" + digitsOnly.substring(2)
    }
}

/** A horizontal strip of selected photos (first = cover, marked with a star) plus an "add" tile. */
@Composable
fun PhotoStrip(
    imagePaths: List<String>,
    onAddClick: () -> Unit,
    onRemove: (String) -> Unit
) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(imagePaths) { path ->
            Box(modifier = Modifier.size(104.dp)) {
                AsyncImage(
                    model = path,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentScale = ContentScale.Crop
                )
                if (imagePaths.firstOrNull() == path) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .background(AmbreDore, MaterialTheme.shapes.extraSmall)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(11.dp))
                            Text("Couverture", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 3.dp))
                        }
                    }
                }
                IconButton(
                    onClick = { onRemove(path) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(26.dp)
                        .padding(2.dp)
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.85f), MaterialTheme.shapes.extraSmall)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Retirer", modifier = Modifier.size(14.dp))
                }
            }
        }
        item {
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onAddClick() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        if (imagePaths.isEmpty()) Icons.Default.PhotoCamera else Icons.Default.AddPhotoAlternate,
                        contentDescription = "Ajouter des photos",
                        tint = VioletVif
                    )
                    Text(
                        "Ajouter",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = VioletVif,
    focusedLabelColor = VioletVif,
    cursorColor = AmbreDore
)

@Composable
private fun FormSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(
            title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
        )
        content()
    }
}
