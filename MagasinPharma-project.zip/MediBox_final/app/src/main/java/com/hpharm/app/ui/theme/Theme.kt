package com.hpharm.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColors = darkColorScheme(
    primary = VioletVif,
    onPrimary = BlancCasse,
    primaryContainer = VioletProfond,
    onPrimaryContainer = BlancCasse,
    secondary = AmbreDore,
    onSecondary = EncreProfond,
    secondaryContainer = AmbreProfond,
    tertiary = CorailVif,
    onTertiary = BlancCasse,
    tertiaryContainer = CorailProfond,
    background = EncreProfond,
    onBackground = BlancCasse,
    surface = EncreSurfaceHaute,
    onSurface = BlancCasse,
    surfaceVariant = EncreSurface,
    onSurfaceVariant = GrisViolet,
    error = CorailVif,
    onError = BlancCasse,
    errorContainer = CorailProfond,
    onErrorContainer = BlancCasse,
    outline = EncreLigne
)

private val LightColors = lightColorScheme(
    primary = VioletVif,
    onPrimary = Color.White,
    primaryContainer = VioletPale,
    onPrimaryContainer = VioletProfond,
    secondary = AmbreProfond,
    onSecondary = Color.White,
    tertiary = CorailVif,
    onTertiary = Color.White,
    tertiaryContainer = CorailPale,
    background = IvoireFond,
    onBackground = EncreTexte,
    surface = IvoireCarte,
    onSurface = EncreTexte,
    surfaceVariant = VioletPale,
    onSurfaceVariant = GrisTexte,
    error = CorailProfond,
    errorContainer = CorailPale
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

/**
 * Dark is this app's signature look, used by default regardless of system setting —
 * a deliberate brand choice, not a fallback. Pass [darkTheme] = false to opt into light.
 */
@Composable
fun HpharmTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
